import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CandidateRegistration extends JFrame {
    private JTextField nameField;
    private JTextField rollNoField;
    private JTextField partyNameField;
    private JButton registerButton;

    public CandidateRegistration() {
        setTitle("Candidate Registration");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(4, 2, 10, 10));

        // Name Field
        JLabel nameLabel = new JLabel("Candidate Name:");
        nameField = new JTextField();
        add(nameLabel);
        add(nameField);

        // Roll Number Field
        JLabel rollNoLabel = new JLabel("Roll No:");
        rollNoField = new JTextField();
        add(rollNoLabel);
        add(rollNoField);

        // Party Name Field
        JLabel partyNameLabel = new JLabel("Party Name:");
        partyNameField = new JTextField();
        add(partyNameLabel);
        add(partyNameField);

        // Register Button
        registerButton = new JButton("Register");
        add(new JLabel());  // Placeholder for layout
        add(registerButton);

        // Register Button Action Listener
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerCandidate();
            }
        });

        setVisible(true);
    }

    // Method to handle candidate registration
    private void registerCandidate() {
        String name = nameField.getText();
        String rollNo = rollNoField.getText();
        String partyName = partyNameField.getText();

        // Validate that fields are not empty
        if (name.isEmpty() || rollNo.isEmpty() || partyName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields must be filled out!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Try inserting candidate into the database
        try (Connection conn = database.getConnection()) {
            if (conn == null) {
                JOptionPane.showMessageDialog(this, "Failed to connect to the database.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String query = "INSERT INTO candidates (name, roll_no, party_name, vote_count) VALUES (?, ?, ?, 0)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, name);
            stmt.setString(2, rollNo);
            stmt.setString(3, partyName);

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Candidate registered successfully.");
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to register candidate.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Clear the fields after successful registration
    private void clearFields() {
        nameField.setText("");
        rollNoField.setText("");
        partyNameField.setText("");
    }

    public static void main(String[] args) {
        new CandidateRegistration();
    }
}
