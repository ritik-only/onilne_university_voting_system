import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Voting extends JFrame {
    private JLabel rollNoLabel;  // Label to display the logged-in roll number
    private JButton voteButton;
    private JButton viewResultsButton;
    private JPanel candidatePanel;
    private ButtonGroup candidateButtonGroup;
    private String rollNo;  // Store the roll number after logging in

    public Voting() {
        setTitle("University Online Voting System");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        // Create the BackgroundPanel and set it as the content pane
        BackgroundPanel backgroundPanel = new BackgroundPanel("D:\\java\\elect2\\votingapp\\voteimg1.jpg"); // Use your image path here
        backgroundPanel.setLayout(new GridBagLayout()); // Use GridBagLayout for better control over positioning
        setContentPane(backgroundPanel);

        // Set up layout constraints for centering the components
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 20, 150); // Set padding between components
        gbc.fill = GridBagConstraints.HORIZONTAL; // Allow components to grow horizontally

        // Create a panel for holding the voting components, making it transparent
        JPanel contentPanel = new JPanel();
        contentPanel.setOpaque(false);  // Make panel transparent
        contentPanel.setLayout(new GridBagLayout());  // Use GridBagLayout inside the content panel

        // Roll Number Label
        gbc.gridx = 0;  // First column
        gbc.gridy = 0;  // First row
        gbc.gridwidth = 2;  // Span across 2 columns
        rollNoLabel = new JLabel("Your Roll No.: ");
        rollNoLabel.setHorizontalAlignment(SwingConstants.CENTER);  // Center the text
        contentPanel.add(rollNoLabel, gbc);

        // Login field for roll number
        gbc.gridy = 1;  // Second row
        JTextField rollNoField = new JTextField(15);
        contentPanel.add(rollNoField, gbc);

        // Login button to register the roll number
        gbc.gridy = 2;  // Third row
        JButton loginButton = new JButton("Login");
        contentPanel.add(loginButton, gbc);

        // Candidates Radio Buttons
        gbc.gridy = 3;  // Fourth row
        JLabel candidateLabel = new JLabel("Select Candidate:");
        candidateLabel.setHorizontalAlignment(SwingConstants.CENTER);
        contentPanel.add(candidateLabel, gbc);

        // Panel for candidate radio buttons
        gbc.gridy = 4;  // Fifth row
        candidatePanel = new JPanel();
        candidatePanel.setOpaque(false);  // Make panel transparent
        candidatePanel.setLayout(new BoxLayout(candidatePanel, BoxLayout.Y_AXIS));
        contentPanel.add(candidatePanel, gbc);

        // Vote Button
        gbc.gridy = 5;  // Sixth row
        voteButton = new JButton("Vote");
        contentPanel.add(voteButton, gbc);

        // View Results Button
        gbc.gridy = 6;  // Seventh row
        viewResultsButton = new JButton("View Results");
        contentPanel.add(viewResultsButton, gbc);

        // Add contentPanel to the main background panel, with adjusted positioning
        gbc.gridx = 0;
        gbc.gridy = 0;
        backgroundPanel.add(contentPanel, gbc);

        // Add action listener for login button
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                rollNo = rollNoField.getText();
                if (rollNo.isEmpty()) {
                    JOptionPane.showMessageDialog(Voting.this, "Please enter your roll number.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Set the roll number label to display the logged-in roll number
                rollNoLabel.setText("Your Roll No: " + rollNo);

                // Disable roll number input and login button after successful login
                rollNoField.setEnabled(false);
                loginButton.setEnabled(false);

                // Display a confirmation message
                JOptionPane.showMessageDialog(Voting.this, "Logged in successfully with Roll No: " + rollNo);

                // Load candidates once the user logs in
                addCandidatesToPanel();
            }
        });

        // Add action listener for vote button
        voteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (rollNo != null) {
                    castVote();
                } else {
                    JOptionPane.showMessageDialog(Voting.this, "Please log in first.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Add action listener for view results button
        viewResultsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showResults();
            }
        });

        setVisible(true);
    }

    // Background panel class to draw image
    class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel(String imagePath) {
            backgroundImage = new ImageIcon(imagePath).getImage();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);  // Draw the image to cover the panel
        }
    }

    // Fetch candidates from the database and create radio buttons
    private void addCandidatesToPanel() {
        candidateButtonGroup = new ButtonGroup();
        candidatePanel.removeAll();  // Clear previous candidates if any
        String[] candidates = getCandidates();  // Fetch candidate names from the database

        if (candidates.length == 0) {
            JLabel noCandidatesLabel = new JLabel("No candidates available.");
            candidatePanel.add(noCandidatesLabel);
        } else {
            for (String candidate : candidates) {
                JRadioButton radioButton = new JRadioButton(candidate);
                candidateButtonGroup.add(radioButton);
                candidatePanel.add(radioButton);
            }
        }
        candidatePanel.revalidate();
        candidatePanel.repaint();
    }

    // Fetch candidates from the database
    private String[] getCandidates() {
        try (Connection conn = database.getConnection()) {
            if (conn == null) {
                System.err.println("Connection to database failed.");
                return new String[] {};  // Return empty array if connection fails
            }

            String query = "SELECT name FROM candidates";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            List<String> candidatesList = new ArrayList<>();

            while (rs.next()) {
                String candidateName = rs.getString("name");
                candidatesList.add(candidateName);  // Add to list
            }

            return candidatesList.toArray(new String[0]);
        } catch (SQLException e) {
            e.printStackTrace();
            return new String[] {};
        }
    }

    // Method to cast a vote
    private void castVote() {
        String selectedCandidate = getSelectedCandidate();

        if (rollNo == null || selectedCandidate == null) {
            JOptionPane.showMessageDialog(this, "Please log in and select a candidate.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = database.getConnection()) {
            String checkVoteQuery = "SELECT * FROM votes WHERE roll_no = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkVoteQuery);
            checkStmt.setString(1, rollNo);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "You have already voted.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String updateVoteCount = "UPDATE candidates SET vote_count = vote_count + 1 WHERE name = ?";
            PreparedStatement stmt = conn.prepareStatement(updateVoteCount);
            stmt.setString(1, selectedCandidate);
            stmt.executeUpdate();

            String insertVote = "INSERT INTO votes (roll_no, candidate_name) VALUES (?, ?)";
            PreparedStatement insertStmt = conn.prepareStatement(insertVote);
            insertStmt.setString(1, rollNo);
            insertStmt.setString(2, selectedCandidate);
            insertStmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Vote casted successfully for " + selectedCandidate);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "An error occurred while casting the vote.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String getSelectedCandidate() {
        Iterator<AbstractButton> buttons = candidateButtonGroup.getElements().asIterator();
        while (buttons.hasNext()) {
            AbstractButton button = buttons.next();
            if (button.isSelected()) {
                return button.getText();
            }
        }
        return null;
    }

    private void showResults() {
        StringBuilder results = new StringBuilder("Voting Results:\n");

        try (Connection conn = database.getConnection()) {
            String query = "SELECT name, vote_count FROM candidates";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String candidateName = rs.getString("name");
                int voteCount = rs.getInt("vote_count");
                results.append(candidateName).append(": ").append(voteCount).append(" votes\n");
            }

            JOptionPane.showMessageDialog(this, results.toString(), "Results", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "An error occurred while fetching results.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new Voting();
    }
}
