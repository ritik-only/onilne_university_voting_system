import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class login extends JFrame {
    private JTextField rollNoField;
    private JPasswordField passwordField;
    private JButton loginButton, createAccountButton, registerCandidateButton;

    public login() {
        setTitle("University Voting System - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximize the window to full screen
        setLayout(new BorderLayout());

        // Create the header panel for the title
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(240, 248, 255)); // Light sky blue background
        
        // Create a custom header label with multi-colored letters
        JPanel coloredHeaderPanel = new JPanel();
        coloredHeaderPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        String headerText = "ELECTRONIC VOTING...";
        Color[] colors = {
            Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE,
            Color.MAGENTA, Color.PINK, Color.BLACK, new Color(128, 0, 128),
            Color.DARK_GRAY, Color.LIGHT_GRAY, new Color(128, 128, 0)
        };

        for (int i = 0; i < headerText.length(); i++) {
            JLabel letterLabel = new JLabel(String.valueOf(headerText.charAt(i)));
            letterLabel.setFont(new Font("Serif", Font.BOLD, 60));
            letterLabel.setForeground(colors[i % colors.length]);
            coloredHeaderPanel.add(letterLabel);
        }

        headerPanel.add(coloredHeaderPanel);
        
        // Create the main panel for input fields and buttons
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(new Color(240, 248, 255)); // Light sky blue background
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(20, 20, 20, 20); // Adjusting insets for better spacing
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Title Label
        JLabel titleLabel = new JLabel("User Login");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 36)); // Larger font for full screen
        titleLabel.setForeground(new Color(0, 102, 204)); // Dark blue color
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        mainPanel.add(titleLabel, gbc);

        // Roll Number Label and Field
        JLabel rollNoLabel = new JLabel("Roll Number:");
        rollNoLabel.setFont(new Font("Arial", Font.PLAIN, 20)); // Adjusted font size
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(rollNoLabel, gbc);

        rollNoField = new JTextField(20);
        rollNoField.setFont(new Font("Arial", Font.PLAIN, 20));
        gbc.gridx = 1;
        gbc.gridy = 1;
        mainPanel.add(rollNoField, gbc);

        // Password Label and Field
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(passwordLabel, gbc);

        passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 20));
        gbc.gridx = 1;
        gbc.gridy = 2;
        mainPanel.add(passwordField, gbc);

        // Buttons Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());
        buttonPanel.setBackground(new Color(240, 248, 255));

        loginButton = new JButton("Login");
        loginButton.setFont(new Font("Arial", Font.BOLD, 20));
        loginButton.setBackground(new Color(0, 153, 255));
        loginButton.setForeground(Color.WHITE);

        createAccountButton = new JButton("Create Account");
        createAccountButton.setFont(new Font("Arial", Font.BOLD, 20));
        createAccountButton.setBackground(new Color(102, 204, 102));
        createAccountButton.setForeground(Color.WHITE);

        // Adding a new button for Candidate Registration
        registerCandidateButton = new JButton("Register as Candidate");
        registerCandidateButton.setFont(new Font("Arial", Font.BOLD, 20));
        registerCandidateButton.setBackground(new Color(255, 153, 51));
        registerCandidateButton.setForeground(Color.WHITE);

        buttonPanel.add(loginButton);
        buttonPanel.add(createAccountButton);
        buttonPanel.add(registerCandidateButton); // Add the new button to the panel

        // Add action listeners for buttons
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Login();  // Call Login method to handle the login process
            }
        });

        createAccountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createAccount();  // Handle account creation process
            }
        });

        // Add action listener for the new Candidate Registration button
        registerCandidateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new CandidateRegistration(); // Open the Candidate Registration window
                dispose(); // Close login window after opening candidate registration
            }
        });

        // Add components to the frame
        add(headerPanel, BorderLayout.NORTH); // Add header panel at the top
        add(mainPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    // Method to handle login
    private void Login() {
        String rollNo = rollNoField.getText();
        String password = new String(passwordField.getPassword());

        if (rollNo.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both Roll Number and Password.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = database.getConnection()) {
            String query = "SELECT * FROM users WHERE roll_no = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, rollNo);
            stmt.setString(2, password); // Passwords should be hashed in real-world applications
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                // Successfully logged in, open the voting page
                JOptionPane.showMessageDialog(this, "Login successful. Welcome!");
                System.out.println("Navigating to Voting page..."); // Debug line for console
                
                try {
                    new Voting(); // Ensure the Voting class is defined and accessible
                    dispose(); // Close the login window
                } catch (Exception ex) {
                    System.out.println("Error opening Voting page: " + ex.getMessage());
                    JOptionPane.showMessageDialog(this, "An error occurred while opening the Voting page.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Roll Number or Password.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "An error occurred while logging in.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to handle account creation
    private void createAccount() {
        String rollNo = rollNoField.getText();
        String password = new String(passwordField.getPassword());

        if (rollNo.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both Roll Number and Password.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = database.getConnection()) {
            String query = "INSERT INTO users (roll_no, password) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, rollNo);
            stmt.setString(2, password); // In real-world apps, store hashed password
            int rowsInserted = stmt.executeUpdate();

            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Account created successfully. You can now log in.");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to create account.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            if (e.getErrorCode() == 1062) { // Duplicate entry for roll_no
                JOptionPane.showMessageDialog(this, "Roll Number already exists. Please choose a different Roll Number.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "An error occurred while creating the account.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        new login(); // Open the login window
    }
}
